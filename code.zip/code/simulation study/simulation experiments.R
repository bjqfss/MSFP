setwd(dir = "E:/BaiduSyncdisk/Paper-Now/2021-FS/Revision/R4/sub/code")

library(snow)


source("simulation study/simdat.R")
simdatr <- simdat(dvec= c(4,1,25), corvec = c(0.85, 0.1), nvec=c(40,40), test.nvec = c(10,10), thr=2, seeds=1)
dat.mode <- simdatr$data.mode; modes <- simdatr$modes
test.list <- simdatr$test.list
dat.list <- test.list$dat.list
y.test <- test.list$y.test
n.test <- length(y.test)
prop <- c(0.3, 0.6, 0.9)
n.prop <- length(prop)
curtmat <- ceiling(tcrossprod(y.test, prop))
rulmat <- -curtmat+y.test
test <- list()
for (indp in 1:n.prop) {
  templist <- list()
  for (i in 1:n.test) {
    templist[[i]] <- dat.list[[i]][1:curtmat[i,indp],]
  }
  test[[indp]] <- list(dat = templist, curtvec= curtmat[,indp], rul = rulmat[,indp])
}
#save(y.test, file = "simulation study/y.test.RData")
#save(test, file = "simulation study/test.RData")
#save(dat.mode, file = "simulation study/datmode.RData")
#save(modes, file = "simulation study/modes.RData")


##---------------------------------------------------------------------------------------- ##
load(file = "simulation study/datmode.RData")
load(file = "simulation study/modes.RData")
varnames <- names(dat.mode)
d <- dim(dat.mode)[2]
y <- table(dat.mode[,2])
indv <- as.numeric(names(y))
xrange <- range(0,max(dat.mode[,3]))
colvec <- c("black","grey")
sen <- c(varnames[1:3], rep("Informative sensor data", 4), rep("Non-informative sensor data", 26))
par(mfrow=c(1,2),mar=c(c(2.5, 2.5, 0.5, 0.5)))
for (j in c(5,33)) {
  yrange <- range(min(dat.mode[,j]), max(dat.mode[j]))
  plot(xrange, yrange, type="n", xlab="Time", ylab = sen[j],mgp=c(1.5,0.5,0))
  for (i in indv) {
    dati <- dat.mode[dat.mode[,2]==i,]
    lines(x=dati[,3],y=dati[,j], col=colvec[as.numeric(dati[1,1]>0)+1],lwd=2)
  }
}



## ----------------------------------------------------------------------------------------- ##
## experiment 1 ##
seeds=1
sim.exp <- function(seeds){
  options(warn = -1)
  zeta <- 0.1
  source(file = "method.R")
  source(file = "competing methods.R")
  load(file = "simulation study/datmode.RData")
  load(file = "simulation study/modes.RData")
  
  org.datr <- org.dat(dat.mode=dat.mode, modes=modes,zeta=zeta, seeds=seeds)
  datl <- org.datr$datl
  datu <- org.datr$datu
  ztu <- datu[,1]
  yu <- table(datu[,2])
  zu <- sapply(1:length(yu), function(i) ztu[sum(yu[1:i])])
  datu <- datu[,-1]
  traindat <- rbind(datl[,-1],datu)
  
  # identify failure modes
  system.time(fm.idtr <- fm.idt(datl, datu, tolsize=1000, 
                                kerwid=NULL, lamv1 = 2^c((-6):6), lamv2 = 2^c((-6):6)))
  
  system.time(laprls <- fm.idt(datl, datu, tolsize=1000, weighted=FALSE,
                                 kerwid=NULL, lamv1 = 2^c((-6):6), lamv2 = 2^c((-6):6)))
  
  system.time(rls <- fm.idt(datl, datu, tolsize=1000, weighted=FALSE,
                               kerwid=NULL, lamv1 = 2^c((-6):6), lamv2 = 0))
  
  system.time(hrls <- fm.idt(datl, datu, tolsize=1000, weighted=TRUE,
                               kerwid=NULL, lamv1 = 2^c((-6):6), lamv2 = 0))
  
  # load test data
  load(file = "simulation study/test.RData")
  load(file = "simulation study/y.test.RData")
  n.prop <- length(test)
  n.test <- length(y.test)
  results <- array(0, dim = c(n.test, 7, n.prop))
  
  for (indp in 1:n.prop) {
    test.list <- test[[indp]]
    dat.list <- test.list$dat
    rul.test <- test.list$rul
    curtvec <- test.list$curtvec
    y.test <- rul.test+curtvec
    rul.mat=matrix(0,nrow = n.test, ncol=3)
    fm.mat <- matrix(0,nrow = n.test, ncol=4)
    for (i in 1:n.test) {
      testdat <- dat.list[[i]]
      
      try(fit1 <- prog1(testdat, traindat, fm.idtr, fve=0.85, direct=FALSE))
      rul.mat[i,1] <- fit1[["rul.est"]]
      try(rul.mat[i,2] <- joint.prog1(testdat, traindat, fve=0.85, direct=TRUE))
      try(sep.fit1 <- sep.prog1(testdat, fm.idtr, fve=0.85, direct=FALSE))
      rul.mat[i,3] <- sep.fit1[["rul.est"]]
      
      fm.mat[i,1] <- fit1[["fm.test"]]
      fm.mat[i,2] <- ifm(testdat, traindat, laprls, weighted=FALSE)
      fm.mat[i,3] <- ifm(testdat, traindat, rls, weighted=FALSE)
      fm.mat[i,4] <- ifm(testdat, traindat, hrls, weighted=TRUE)
    } # for i
    results[,,indp] <- cbind(abs(rul.mat-rul.test)/y.test, fm.mat)
  } # for indp
  return(results)
} # sim.exp


library(parallel)
n.seed=50
n_cores <- detectCores() # number of cores for parallel processing
cl <- makeCluster(round(n_cores*0.7))
# try(sim1 <- parSapply(cl,1:n.seed,FUN=sim.exp, simplify = "array"))
stopCluster(cl)

##--------------------------------------------------------------------------------------------------------- ##


## ----------------------------------------------------------------------------------------- ##
## experiment 2 ##
seeds=1
sim.exp <- function(seeds){
  options(warn = -1)
  zeta <- 0.05
  source(file = "method.R")
  source(file = "competing methods.R")
  load(file = "simulation study/datmode.RData")
  load(file = "simulation study/modes.RData")
  
  org.datr <- org.dat(dat.mode=dat.mode, modes=modes,zeta=zeta, seeds=seeds)
  datl <- org.datr$datl
  datu <- org.datr$datu
  ztu <- datu[,1]
  yu <- table(datu[,2])
  zu <- sapply(1:length(yu), function(i) ztu[sum(yu[1:i])])
  datu <- datu[,-1]
  traindat <- rbind(datl[,-1],datu)
  
  # identify failure modes
  system.time(fm.idtr <- fm.idt(datl, datu, tolsize=1000, 
                                kerwid=NULL, lamv1 = 2^c((-6):6), lamv2 = 2^c((-6):6)))
  
  system.time(laprls <- fm.idt(datl, datu, tolsize=1000, weighted=FALSE,
                               kerwid=NULL, lamv1 = 2^c((-6):6), lamv2 = 2^c((-6):6)))
  
  system.time(rls <- fm.idt(datl, datu, tolsize=1000, weighted=FALSE,
                            kerwid=NULL, lamv1 = 2^c((-6):6), lamv2 = 0))
  
  system.time(hrls <- fm.idt(datl, datu, tolsize=1000, weighted=TRUE,
                             kerwid=NULL, lamv1 = 2^c((-6):6), lamv2 = 0))
  
  # load test data
  load(file = "simulation study/test.RData")
  load(file = "simulation study/y.test.RData")
  n.prop <- length(test)
  n.test <- length(y.test)
  results <- array(0, dim = c(n.test, 7, n.prop))
  
  for (indp in 1:n.prop) {
    test.list <- test[[indp]]
    dat.list <- test.list$dat
    rul.test <- test.list$rul
    curtvec <- test.list$curtvec
    y.test <- rul.test+curtvec
    rul.mat=matrix(0,nrow = n.test, ncol=3)
    fm.mat <- matrix(0,nrow = n.test, ncol=4)
    for (i in 1:n.test) {
      testdat <- dat.list[[i]]
      
      try(fit1 <- prog1(testdat, traindat, fm.idtr, fve=0.85, direct=FALSE))
      rul.mat[i,1] <- fit1[["rul.est"]]
      try(rul.mat[i,2] <- joint.prog1(testdat, traindat, fve=0.85, direct=TRUE))
      try(sep.fit1 <- sep.prog1(testdat, fm.idtr, fve=0.85, direct=FALSE))
      rul.mat[i,3] <- sep.fit1[["rul.est"]]
      
      fm.mat[i,1] <- fit1[["fm.test"]]
      fm.mat[i,2] <- ifm(testdat, traindat, laprls, weighted=FALSE)
      fm.mat[i,3] <- ifm(testdat, traindat, rls, weighted=FALSE)
      fm.mat[i,4] <- ifm(testdat, traindat, hrls, weighted=TRUE)
    } # for i
    results[,,indp] <- cbind(abs(rul.mat-rul.test)/y.test, fm.mat)
  } # for indp
  return(results)
} # sim.exp


library(parallel)
n.seed=50
n_cores <- detectCores() # number of cores for parallel processing
cl <- makeCluster(round(n_cores*0.7))
# try(sim2 <- parSapply(cl,1:n.seed,FUN=sim.exp, simplify = "array"))
stopCluster(cl)


## ----------------------------------------------------------------------------------------- ##
## experiment 3 ##
seeds=1
sim.exp <- function(seeds){
  options(warn = -1)
  zeta <- 0.15
  source(file = "method.R")
  source(file = "competing methods.R")
  load(file = "simulation study/datmode.RData")
  load(file = "simulation study/modes.RData")
  
  org.datr <- org.dat(dat.mode=dat.mode, modes=modes,zeta=zeta, seeds=seeds)
  datl <- org.datr$datl
  datu <- org.datr$datu
  ztu <- datu[,1]
  yu <- table(datu[,2])
  zu <- sapply(1:length(yu), function(i) ztu[sum(yu[1:i])])
  datu <- datu[,-1]
  traindat <- rbind(datl[,-1],datu)
  
  # identify failure modes
  system.time(fm.idtr <- fm.idt(datl, datu, tolsize=1000, 
                                kerwid=NULL, lamv1 = 2^c((-6):6), lamv2 = 2^c((-6):6)))
  
  system.time(laprls <- fm.idt(datl, datu, tolsize=1000, weighted=FALSE,
                               kerwid=NULL, lamv1 = 2^c((-6):6), lamv2 = 2^c((-6):6)))
  
  system.time(rls <- fm.idt(datl, datu, tolsize=1000, weighted=FALSE,
                            kerwid=NULL, lamv1 = 2^c((-6):6), lamv2 = 0))
  
  system.time(hrls <- fm.idt(datl, datu, tolsize=1000, weighted=TRUE,
                             kerwid=NULL, lamv1 = 2^c((-6):6), lamv2 = 0))
  
  # load test data
  load(file = "simulation study/test.RData")
  load(file = "simulation study/y.test.RData")
  n.prop <- length(test)
  n.test <- length(y.test)
  results <- array(0, dim = c(n.test, 7, n.prop))
  
  for (indp in 1:n.prop) {
    test.list <- test[[indp]]
    dat.list <- test.list$dat
    rul.test <- test.list$rul
    curtvec <- test.list$curtvec
    y.test <- rul.test+curtvec
    rul.mat=matrix(0,nrow = n.test, ncol=3)
    fm.mat <- matrix(0,nrow = n.test, ncol=4)
    for (i in 1:n.test) {
      testdat <- dat.list[[i]]
      
      try(fit1 <- prog1(testdat, traindat, fm.idtr, fve=0.85, direct=FALSE))
      rul.mat[i,1] <- fit1[["rul.est"]]
      try(rul.mat[i,2] <- joint.prog1(testdat, traindat, fve=0.85, direct=TRUE))
      try(sep.fit1 <- sep.prog1(testdat, fm.idtr, fve=0.85, direct=FALSE))
      rul.mat[i,3] <- sep.fit1[["rul.est"]]
      
      fm.mat[i,1] <- fit1[["fm.test"]]
      fm.mat[i,2] <- ifm(testdat, traindat, laprls, weighted=FALSE)
      fm.mat[i,3] <- ifm(testdat, traindat, rls, weighted=FALSE)
      fm.mat[i,4] <- ifm(testdat, traindat, hrls, weighted=TRUE)
    } # for i
    results[,,indp] <- cbind(abs(rul.mat-rul.test)/y.test, fm.mat)
  } # for indp
  return(results)
} # sim.exp


library(parallel)
n.seed=50
n_cores <- detectCores() # number of cores for parallel processing
cl <- makeCluster(round(n_cores*0.7))
# try(sim3 <- parSapply(cl,1:n.seed,FUN=sim.exp, simplify = "array"))
stopCluster(cl)
## ------------------------------------------------------------------------------------ ##
# simr1 <- array(0, dim = c(3,3,3))
# simr1[,,1] <- apply(sim1[,1:3,,], 2:3, mean)
# simr1[,,2] <- apply(sim2[,1:3,,], 2:3, mean)
# simr1[,,3] <- apply(sim3[,1:3,,], 2:3, mean)
# save(simr1, file = "simulation study/results/simr1.Rdata")

# simr2 <- array(0, dim = c(4,3,3))
gmfun <- function(fm.est, fm.true=rep(c(1,2), each=10)){
  tp <- sum(fm.est[1:10]==1)
  tn <- sum(fm.est[11:20]==2)
  gm <- sqrt(tp/10*tn/10)
  return(gm)
}
# simr2[,,1] <- apply(apply(sim1[,4:7,,], 2:4, gmfun), 1:2, mean)
# simr2[,,2] <- apply(apply(sim2[,4:7,,], 2:4, gmfun), 1:2, mean)
# simr2[,,3] <- apply(apply(sim3[,4:7,,], 2:4, gmfun), 1:2, mean)
# save(simr2, file = "simulation study/results/simr2.Rdata")
# save(aa1,file = "simulation study/results/aa1.Rdata")
# save(aa2,file = "simulation study/results/aa2.Rdata")
##--------------------------------------------------------------------------------------------------------- ##
load(file = "simulation study/results/aa1.Rdata") # diagnosis c(methods, eta, zeta) 
load(file = "simulation study/results/aa2.Rdata") # prognostics c(methods, eta, zeta) 


library(RColorBrewer)
thrvec <- c(0.3,0.6,0.9)
thr.len <- length(thrvec)
colvec=brewer.pal(6,"Set2")[1:6] 
ltyvec=1:6
for (ind in c(1,2,3)) {
  par(mfrow=c(1,1),mar=c(c(2.8, 2.5, 0.5, 0.5)))
  plot(thrvec, seq(from=min(aa2[1:4,,ind]), to=max(aa2[1:4,,]), length.out=thr.len), 
       type="n", xlab=expression(eta), ylab = "Average prediction error",
       mgp=c(1.5,0.5,0),xaxt="n")
  axis(side = 1, at=thrvec, labels = thrvec,mgp=c(1.5,0.5,0))
  for (j in 1:4) {
    lines(x=thrvec, y=aa2[j,,ind], type = "b", col=colvec[j], lty=ltyvec[j], pch=j,lwd=2)
  } # for j
  if(ind==1){
    legend(x="topright", legend = c("EN-FReg","FReg", "S-FReg", "EN-FReg1"),
           pch = 1:4, lty = ltyvec[1:4], col = colvec[1:4], lwd=2)
  }
}



for (ind in c(1,2,3)) {
  par(mfrow=c(1,1),mar=c(c(2.8, 2.5, 0.5, 0.5)))
  plot(thrvec, seq(from=min(aa1[1:4,,ind]), to=max(aa1[1:4,,]), length.out=thr.len), 
       type="n", xlab=expression(eta), ylab = "Average g-mean",
       mgp=c(1.5,0.5,0),xaxt="n")
  axis(side = 1, at=thrvec, labels = thrvec,mgp=c(1.5,0.5,0))
  for (j in 1:6) {
    lines(x=thrvec, y=aa1[j,,ind], type = "b", col=colvec[j], lty=ltyvec[j], pch=j,lwd=2)
  } # for j
  if(ind==1){
    legend(x="topleft", legend = c("HLapRLS-Gaussian", "HLapRLS-linear",
                                   "HLapRLS-polynomial" , "LapRLS", "RLS", "HRLS"),
           pch = 1:6, lty = ltyvec[1:6], col = colvec[1:6], lwd=2)
  }
}

