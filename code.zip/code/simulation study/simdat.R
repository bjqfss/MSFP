## function for generating simulated data
#'@param dvec a vector of length three containing the number of the informative, the weekly-informative, 
#'and the non-informative variables, respectively.
#'@param corvec a vector of length two containing the correlation between the variables 
#'and the system health state.
#'@param nvec a vector of length two containing the number of the training samples with the two failure modes.
#'@param test.nvec a vector of length two containing the number of the test samples with the two failure modes.
#'@param thr the failure threshold.
#'@param seeds the seed of the generator.
simdat <- function(dvec= c(2,2,2), corvec = c(0.8,0.8), nvec=c(40,40), test.nvec = c(10,10), thr=2, seeds){
  library(mvtnorm)
  set.seed(seeds)
  d <- sum(dvec)
  pro=1.25
  mu.theta <- c(1,1.2)
  sd.theta <- c(0.2,0.2)
  mu.theta2 <- 3
  modes <- list(mode1 = c(1:nvec[1]), mode2 = c((nvec[1]+1):sum(nvec[1:2])))
  
  data.mode <- NULL
  
  for (i in 1:nvec[1]) {
    theta.i <- rnorm(n = 1, mean = mu.theta[1], sd = sd.theta[1])
    muvec <- mu.theta2+corvec*(theta.i-mu.theta[1])
    sdvec <- sd.theta[1]*sqrt(1-corvec^2)
    yi <- ceiling(exp(-theta.i/thr)*500)
    theta1 <- rnorm(n = dvec[1], mean = muvec[1], sd = sdvec[1])
    theta2 <- rnorm(n = dvec[2], mean = muvec[2], sd = sdvec[2])
    theta <- c(theta1, theta2)
    dattemp1 <- matrix(log(1:yi), ncol = 1)%*%matrix(theta, nrow = 1)+
      matrix(rnorm(n = yi*sum(dvec[1:2]), mean = 0, sd = 0.1), nrow = yi)
    dattemp2 <- matrix(rnorm(n = yi*dvec[3], mean = 0, sd = 1), nrow = yi)
    dattemp <- cbind(rep(-1,yi), rep(i, yi), c(1:yi), dattemp1, dattemp2)
    dattemp <- data.frame(dattemp)
    data.mode <- rbind(data.mode, dattemp)
  } # for i
  
  
  for (i in (1+nvec[1]):sum(nvec[1:2])) {
    theta.i <- rnorm(n = 1, mean = mu.theta[2], sd = sd.theta[2])*pro
    muvec <- mu.theta2+corvec*(theta.i-mu.theta[2])
    sdvec <- sd.theta[2]*sqrt(1-corvec^2)
    yi <- ceiling(exp(-theta.i/thr)*500)
    theta1 <- rnorm(n = dvec[1], mean = muvec[1], sd = sdvec[1])
    theta2 <- rnorm(n = dvec[2], mean = muvec[2], sd = sdvec[2])
    theta <- c(theta1, theta2)*pro
    dattemp1 <- matrix(log(1:yi), ncol = 1)%*%matrix(theta, nrow = 1)+
      matrix(rnorm(n = yi*sum(dvec[1:2]), mean = 0, sd = 0.1), nrow = yi)
    dattemp2 <- matrix(rnorm(n = yi*dvec[3], mean = 0, sd = 1), nrow = yi)
    dattemp <- cbind(rep(1,yi), rep(i, yi), c(1:yi), dattemp1, dattemp2)
    dattemp <- data.frame(dattemp)
    data.mode <- rbind(data.mode, dattemp)
  } # for i
  
  
  # generate test data sets 
  dat.list <- list()
  y.test <- c()
  modes.test <- list(mode1 = c(1:test.nvec[1]), mode2 = c((test.nvec[1]+1):sum(test.nvec)))
  
  for (i in c(1:test.nvec[1])) {
    theta.i <- rnorm(n = 1, mean = mu.theta[1], sd = sd.theta[1])
    muvec <- mu.theta2+corvec*(theta.i-mu.theta[1])
    sdvec <- sd.theta[1]*sqrt(1-corvec^2)
    yi <- ceiling(exp(-theta.i/thr)*500)
    theta1 <- rnorm(n = dvec[1], mean = muvec[1], sd = sdvec[1])
    theta2 <- rnorm(n = dvec[2], mean = muvec[2], sd = sdvec[2])
    theta <- c(theta1, theta2)
    dattemp1 <- matrix(log(1:yi), ncol = 1)%*%matrix(theta, nrow = 1)+
      matrix(rnorm(n = yi*sum(dvec[1:2]), mean = 0, sd = 0.1), nrow = yi)
    dattemp2 <- matrix(rnorm(n = yi*dvec[3], mean = 0, sd = 1), nrow = yi)
    dattemp <- cbind(dattemp1, dattemp2)
    dat.list[[i]] <- data.frame(dattemp)
    y.test[i] <- yi
  }
  
  for (i in c((test.nvec[1]+1):sum(test.nvec))) {
    theta.i <- rnorm(n = 1, mean = mu.theta[2], sd = sd.theta[2])*pro
    muvec <- mu.theta2+corvec*(theta.i-mu.theta[2])
    sdvec <- sd.theta[1]*sqrt(1-corvec^2)
    yi <- ceiling(exp(-theta.i/thr)*500)
    theta1 <- rnorm(n = dvec[1], mean = muvec[1], sd = sdvec[1])
    theta2 <- rnorm(n = dvec[2], mean = muvec[2], sd = sdvec[2])
    theta <- c(theta1, theta2)*pro
    dattemp1 <- matrix(log(1:yi), ncol = 1)%*%matrix(theta, nrow = 1)+
      matrix(rnorm(n = yi*sum(dvec[1:2]), mean = 0, sd = 0.1), nrow = yi)
    dattemp2 <- matrix(rnorm(n = yi*dvec[3], mean = 0, sd = 1), nrow = yi)
    dattemp <- cbind(dattemp1, dattemp2)
    dat.list[[i]] <- data.frame(dattemp)
    y.test[i] <- yi
  }
  test.list <- list(dat.list = dat.list, y.test = y.test)
  results <- list(modes = modes, data.mode = data.mode, test.list = test.list)
  return(results)
}


#simdatr <- simdat(dvec= c(2,2,2), corvec = c(0.8, 0.8), nvec=c(40,40), test.nvec = c(10,10), thr=2, seeds=1)
#dat.mode <- simdatr$data.mode; modes <- simdatr$modes
#org.datr <- org.dat(dat.mode=dat.mode, modes=modes,zeta=0.2, seeds=1)
#plotfun(org.datr=org.datr, test.list=NULL, mfrows=c(3,2), colvec = c("black", "red"))