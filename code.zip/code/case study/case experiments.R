setwd(dir = "E:/BaiduSyncdisk/Paper-Now/2021-FS/Revision/R4/sub/code")
library(snow)

load(file = "case study/dat.mode.RData")
load(file = "case study/modes.RData")
varnames <- names(dat.mode)
d <- dim(dat.mode)[2]
y <- table(dat.mode[,2])
indv <- as.numeric(names(y))
xrange <- range(0,max(dat.mode[,3]))
colvec <- c("black","grey")
par(mfrow=c(5,3),mar=c(c(2.5, 2.5, 0.5, 0.5)))
for (j in 4:d) {
  yrange <- range(min(dat.mode[,j]), max(dat.mode[j]))
  plot(xrange, yrange, type="n", xlab="", ylab = varnames[j],mgp=c(1.5,0.5,0))
  for (i in indv) {
    dati <- dat.mode[dat.mode[,2]==i,]
    lines(x=dati[,3],y=dati[,j], col=colvec[as.numeric(dati[1,1]>0)+1])
  }
}



## --------------------------------------------------------------------------------------- ##
## experiment 1 ##
seeds=1
case.exp <- function(seeds){
  options(warn = -1)
  zeta <- 0.025
  load(file = "case study/dat.mode.RData")
  load(file = "case study/modes.RData")
  source(file = "method.R")
  source(file = "competing methods.R")
  org.datr <- org.dat(dat.mode=dat.mode, modes=modes,zeta=zeta, seeds=seeds)
  datl <- org.datr$datl
  datu <- org.datr$datu
  ztu <- datu[,1]
  yu <- table(datu[,2])
  zu <- sapply(1:length(yu), function(i) ztu[sum(yu[1:i])])
  datu <- datu[,-1]
  traindat <- rbind(datl[,-1],datu)
  
  # identify failure modes
  try(fm.idtr <- fm.idt(datl, datu, tolsize=1000, 
                        lamv1 = 2^c((-6):6), lamv2 = 2^c((-6):6)))
  
  try(fm.idtr1 <- fm.idt(datl, datu, tolsize=1000, 
                         lamv1 = 2^c((-6):6), lamv2 = 0))
  
  # load test data set
  load(file = "case study/test.list.RData")
  dat.list <- test.list$dat
  rul.test <- test.list$rul
  curtvec <- test.list$curtvec
  y.test <- curtvec+rul.test
  n.test <- length(rul.test)
  # n.test=2
  rul.mat=matrix(0,nrow = n.test, ncol=3)
  for (i in 1:n.test) {
    testdat <- dat.list[[i]]
    
    try(rul.mat[i,1] <- prog1(testdat, traindat, fm.idtr, fve=0.85, direct=TRUE))
    
    try(rul.mat[i,2] <- joint.prog1(testdat, traindat, fve=0.85, direct=TRUE))
    
    try(rul.mat[i,3] <- sep.prog1(testdat, fm.idtr1, fve=0.85, direct=TRUE))
  }
  return(rul.mat)
} # case.exp

library(parallel)
n.seed=50
n_cores <- detectCores() # number of cores for parallel processing
cl <- makeCluster(round(n_cores*0.7))
# try(case1 <- parSapply(cl,1:n.seed,FUN=case.exp, simplify = "array"))
stopCluster(cl)
# save(case1, file = "case study/results/case1.Rdata")


## --------------------------------------------------------------------------------------- ##
## experiment 2 ##
seeds=1
case.exp <- function(seeds){
  options(warn = -1)
  zeta <- 0.05
  load(file = "case study/dat.mode.RData")
  load(file = "case study/modes.RData")
  source(file = "method.R")
  source(file = "competing methods.R")
  org.datr <- org.dat(dat.mode=dat.mode, modes=modes,zeta=zeta, seeds=seeds)
  datl <- org.datr$datl
  datu <- org.datr$datu
  ztu <- datu[,1]
  yu <- table(datu[,2])
  zu <- sapply(1:length(yu), function(i) ztu[sum(yu[1:i])])
  datu <- datu[,-1]
  traindat <- rbind(datl[,-1],datu)
  
  # identify failure modes
  try(fm.idtr <- fm.idt(datl, datu, tolsize=1000, 
                        kerwid=NULL, lamv1 = 2^c((-6):6), lamv2 = 2^c((-6):6)))
  
  try(fm.idtr1 <- fm.idt(datl, datu, tolsize=1000, 
                         kerwid=NULL, lamv1 = 2^c((-6):6), lamv2 = 0))
  
  # load test data set
  load(file = "case study/test.list.RData")
  dat.list <- test.list$dat
  rul.test <- test.list$rul
  curtvec <- test.list$curtvec
  y.test <- curtvec+rul.test
  n.test <- length(rul.test)
  # n.test=2
  rul.mat=matrix(0,nrow = n.test, ncol=3)
  for (i in 1:n.test) {
    testdat <- dat.list[[i]]
    
    try(rul.mat[i,1] <- prog1(testdat, traindat, fm.idtr, fve=0.85, direct=TRUE))
    
    try(rul.mat[i,2] <- joint.prog1(testdat, traindat, fve=0.85, direct=TRUE))
    
    try(rul.mat[i,3] <- sep.prog1(testdat, fm.idtr1, fve=0.85, direct=TRUE))
  }
  return(rul.mat)
} # case.exp

library(parallel)
n.seed=50
n_cores <- detectCores() # number of cores for parallel processing
cl <- makeCluster(round(n_cores*0.7))
# try(case2 <- parSapply(cl,1:n.seed,FUN=case.exp, simplify = "array"))
stopCluster(cl)
# save(case2, file = "case study/results/case2.Rdata")


## --------------------------------------------------------------------------------------- ##
## experiment 3 ##
seeds=1
case.exp <- function(seeds){
  options(warn = -1)
  zeta <- 0.1
  load(file = "case study/dat.mode.RData")
  load(file = "case study/modes.RData")
  source(file = "method.R")
  source(file = "competing methods.R")
  org.datr <- org.dat(dat.mode=dat.mode, modes=modes,zeta=zeta, seeds=seeds)
  datl <- org.datr$datl
  datu <- org.datr$datu
  ztu <- datu[,1]
  yu <- table(datu[,2])
  zu <- sapply(1:length(yu), function(i) ztu[sum(yu[1:i])])
  datu <- datu[,-1]
  traindat <- rbind(datl[,-1],datu)
  
  # identify failure modes
  try(fm.idtr <- fm.idt(datl, datu, tolsize=1000, 
                        kerwid=NULL, lamv1 = 2^c((-6):6), lamv2 = 2^c((-6):6)))
  
  try(fm.idtr1 <- fm.idt(datl, datu, tolsize=1000, 
                         kerwid=NULL, lamv1 = 2^c((-6):6), lamv2 = 0))
  
  # load test data set
  load(file = "case study/test.list.RData")
  dat.list <- test.list$dat
  rul.test <- test.list$rul
  curtvec <- test.list$curtvec
  y.test <- curtvec+rul.test
  n.test <- length(rul.test)
  # n.test=2
  rul.mat=matrix(0,nrow = n.test, ncol=3)
  for (i in 1:n.test) {
    testdat <- dat.list[[i]]
    
    try(rul.mat[i,1] <- prog1(testdat, traindat, fm.idtr, fve=0.85, direct=TRUE))
    
    try(rul.mat[i,2] <- joint.prog1(testdat, traindat, fve=0.85, direct=TRUE))
    
    try(rul.mat[i,3] <- sep.prog1(testdat, fm.idtr1, fve=0.85, direct=TRUE))
  }
  return(rul.mat)
} # case.exp

library(parallel)
n.seed=50
n_cores <- detectCores() # number of cores for parallel processing
cl <- makeCluster(round(n_cores*0.7))
# try(case3 <- parSapply(cl,1:n.seed,FUN=case.exp, simplify = "array"))
stopCluster(cl)
# save(case3, file = "case study/results/case3.Rdata")


## ----------------------------------------------------------------------------------------- ##
load(file = "case study/results/case1.RData")
load(file = "case study/results/case2.RData")
load(file = "case study/results/case3.RData")
load(file = "case study/test.list.RData")
library(RColorBrewer)
rul.test <- test.list$rul
curtvec <- test.list$curtvec
y.test <- curtvec+rul.test
err.arr1 <- abs(case1-rul.test)/y.test
err1 <- apply(err.arr1, 2, mean)
err1

err.arr2 <- abs(case2-rul.test)/y.test
err2 <- apply(err.arr2, 2, mean)
err2

err.arr3 <- abs(case3-rul.test)/y.test
err3 <- apply(err.arr3, 2, mean)
err3

m.len=3; 
rul.list <- list()
rul.list[[1]] <- case1; rul.list[[2]]=case2; rul.list[[3]]=case3
# save(rul.list,file = "case study/results/rul.list.RData")
load("case study/results/rul.list.RData")

thrvec <- c(100, 80, 60, 40, 20); thr.len <- length(thrvec)
colvec=brewer.pal(4,"Set2")[1:4] 
ltyvec=c(1,2,3,4)
err.mean <- array(0,dim = c(thr.len, m.len,3))
err.sd <- array(0,dim = c(thr.len, m.len,3))

for (il in 1:3) {
  rul.est <- rul.list[[il]]
  err.arr <- abs(rul.est-rul.test)/y.test
  
  for (tl in 1:thr.len) {
    indv <- which(rul.test<=thrvec[tl])
    err.mean[tl,,il] <- apply(err.arr[indv,,], 2, mean)
    err.sd[tl,,il] <- apply(err.arr[indv,,], 2, sd)
  } # for tl
} # for il

aa=c(0.085, 0.069, 0.051, 0.043, 0.040)

for (il in 1:3) {
  par(mfrow=c(1,1),mar=c(c(2.8, 2.5, 0.5, 0.5)))
  plot(thrvec, seq(from=min(err.mean), to=max(err.mean), length.out=thr.len), 
       type="n", xlab="Different levels of actual RUL", ylab = "Average prediction error",mgp=c(1.5,0.5,0))
  for (j in 1:m.len) {
    lines(x=thrvec, y=err.mean[,j,il], type = "b", col=colvec[j], lty=ltyvec[j], pch=j,lwd=2)
  } # for j
  lines(x=thrvec, y=aa, type = "b", col=colvec[m.len+1], lty=ltyvec[m.len+1], pch=m.len+1,lwd=2)
  if(il==1){
    legend(x="topleft", legend = c("The proposed", "HLapRLS-FR", "HRLS-SFR", "HI"),
           pch = 1:(m.len+1), lty = ltyvec[1:(m.len+1)], col = colvec[1:(m.len+1)], lwd=2)
  }
} # for il

caser <- array(0, dim = c(5,6,3))
caser[,1:3,] <- err.mean[,1:3,]
caser[,4,] <- matrix(c(0.10762747, 0.08481659, 0.07270305, 0.06263098, 0.05924560,
  0.09962839, 0.07841181, 0.06448798, 0.04959109, 0.04589159,
                       0.085, 0.072, 0.058, 0.043, 0.040),
                     5,3)
caser[,5,] <- matrix(rep(c(0.09341266, 0.08679802, 0.07435460, 0.07379076, 0.04261038),3),5,3)
caser[,6,] <- matrix(rep(c(0.07170099, 0.08194203, 0.07665601, 0.06069799, 0.03732852),3),5,3)


# save(caser, file = "case study/results/caser.RData")
load(file = "case study/results/caser.RData")
m.len <- 6
thrvec <- c(100, 80, 60, 40, 20); thr.len <- length(thrvec)
colvec=brewer.pal(6,"Set2")[1:6] 
ltyvec=1:6
for (il in 1:3) {
  par(mfrow=c(1,1),mar=c(c(2.8, 2.5, 0.5, 0.5)))
  plot(thrvec, seq(from=min(caser), to=max(caser), length.out=thr.len), 
       type="n", xlab="Different levels of actual RUL", ylab = "Average prediction error",mgp=c(1.5,0.5,0))
  for (j in 1:6) {
    lines(x=thrvec, y=caser[,j,il], type = "b", col=colvec[j], lty=ltyvec[j], pch=j,lwd=2)
  } # for j
  if(il==1){
    legend(x="topleft", legend = c("The proposed", "HLapRLS-FR", "HRLS-SFR", "HI", "CNN", "LSTM"),
           pch = 1:(m.len+1), lty = ltyvec[1:(m.len+1)], col = colvec[1:(m.len+1)], lwd=2)
  }
} # for il